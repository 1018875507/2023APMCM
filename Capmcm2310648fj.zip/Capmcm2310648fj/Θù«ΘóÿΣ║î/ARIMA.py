import numpy as np

def floataver(Y):
    """
    Calculates the three-point and five-point moving averages.
    
    Parameters:
    Y (numpy array): Original time series.
    
    Returns:
    numpy array: Three-point moving averages.
    numpy array: Five-point moving averages.
    """
    n = len(Y)

    # Initialize the moving average arrays with zeros
    floaver3 = np.zeros(n)
    floaver5 = np.zeros(n)

    # Calculate three-point moving averages
    for i in range(3, n):
        floaver3[i] = (Y[i-1] + Y[i-2] + Y[i-3]) / 3

    # Calculate five-point moving averages
    for i in range(5, n):
        floaver5[i] = (Y[i-1] + Y[i-2] + Y[i-3] + Y[i-4] + Y[i-5]) / 5

    return floaver3, floaver5

# Example usage
Y = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
floaver3, floaver5 = floataver(Y)
print("Three-point moving averages:", floaver3)
print("Five-point moving averages:", floaver5)
