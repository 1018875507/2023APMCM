# -*- coding: UTF-8 -*-
import numpy as np
import torch
from torch import nn
import matplotlib.pyplot as plt

# Define LSTM Neural Network class
class LstmRNN(nn.Module):
    """
    LSTM Neural Network for Time Series Prediction.
    Parameters:
    - input_size: The number of input features.
    - hidden_size: The number of units in the hidden layer.
    - output_size: The number of output features.
    - num_layers: The number of stacked LSTM layers.
    """
    def __init__(self, input_size, hidden_size=1, output_size=1, num_layers=1):
        super().__init__()
        # Initializing the LSTM layer
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers)
        # Linear layer to map from hidden state to output
        self.forwardCalculation = nn.Linear(hidden_size, output_size)
    
    def forward(self, _x):
        # Forward pass through LSTM layer
        x, _ = self.lstm(_x)  # _x is input of size (seq_len, batch, input_size)
        s, b, h = x.shape  # x is output of size (seq_len, batch, hidden_size)
        x = x.view(s*b, h)  # Reshape for linear layer
        x = self.forwardCalculation(x)  # Pass through linear layer
        x = x.view(s, b, -1)
        return x

if __name__ == '__main__':
    # Creating synthetic dataset for demonstration
    data_len = 200
    t = np.linspace(0, 12*np.pi, data_len)
    sin_t = np.sin(t)
    cos_t = np.cos(t)

    # Preparing dataset
    dataset = np.zeros((data_len, 2))
    dataset[:,0] = sin_t
    dataset[:,1] = cos_t
    dataset = dataset.astype('float32')

    # Plotting part of the original dataset
    plt.figure()
    plt.plot(t[0:60], dataset[0:60,0], label='sin(t)')
    plt.plot(t[0:60], dataset[0:60,1], label='cos(t)')
    plt.xlabel('t')
    plt.ylim(-1.2, 1.2)
    plt.ylabel('sin(t) and cos(t)')
    plt.legend(loc='upper right')
    plt.show()

    # Splitting dataset into training and testing
    train_data_ratio = 0.5  # Using 50% of data for training
    train_data_len = int(data_len * train_data_ratio)
    train_x = dataset[:train_data_len, 0]
    train_y = dataset[:train_data_len, 1]
    test_x = dataset[train_data_len:, 0]
    test_y = dataset[train_data_len:, 1]

    # Preparing data for LSTM model
    INPUT_FEATURES_NUM = 1
    OUTPUT_FEATURES_NUM = 1
    train_x_tensor = train_x.reshape(-1, 5, INPUT_FEATURES_NUM)  # Batch size of 5
    train_y_tensor = train_y.reshape(-1, 5, OUTPUT_FEATURES_NUM)

    # Converting numpy arrays to PyTorch tensors
    train_x_tensor = torch.from_numpy(train_x_tensor)
    train_y_tensor = torch.from_numpy(train_y_tensor)

    # Initializing LSTM model
    lstm_model = LstmRNN(INPUT_FEATURES_NUM, 16, output_size=OUTPUT_FEATURES_NUM, num_layers=1) # 16 hidden units
    loss_function = nn.MSELoss()
    optimizer = torch.optim.Adam(lstm_model.parameters(), lr=1e-2)

    # Training the LSTM model
    max_epochs = 10000
    for epoch in range(max_epochs):
        output = lstm_model(train_x_tensor)
        loss = loss_function(output, train_y_tensor)
 
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        if loss.item() < 1e-4:
            print(f'Epoch [{epoch+1}/{max_epochs}], Loss: {loss.item():.5f}. Early stopping triggered.')
            break
        elif (epoch+1) % 100 == 0:
            print(f'Epoch: [{epoch+1}/{max_epochs}], Loss:{loss.item():.5f}')

    # Prediction on training dataset
    predictive_y_for_training = lstm_model(train_x_tensor).view(-1, OUTPUT_FEATURES_NUM).data.numpy()

    # Switching to evaluation mode for testing
    lstm_model.eval()
    test_x_tensor = test_x.reshape(-1, 5, INPUT_FEATURES_NUM) # set batch size to 5, the same value with the training set
    test_x_tensor = torch.from_numpy(test_x_tensor)
 
    predictive_y_for_testing = lstm_model(test_x_tensor)
    predictive_y_for_testing = predictive_y_for_testing.view(-1, OUTPUT_FEATURES_NUM).data.numpy()
 
    # ----------------- plot -------------------
    plt.figure()
    plt.plot(t_for_training, train_x, 'g', label='sin_trn')
    plt.plot(t_for_training, train_y, 'b', label='ref_cos_trn')
    plt.plot(t_for_training, predictive_y_for_training, 'y--', label='pre_cos_trn')

    plt.plot(t_for_testing, test_x, 'c', label='sin_tst')
    plt.plot(t_for_testing, test_y, 'k', label='ref_cos_tst')
    plt.plot(t_for_testing, predictive_y_for_testing, 'm--', label='pre_cos_tst')

    plt.plot([t[train_data_len], t[train_data_len]], [-1.2, 4.0], 'r--', label='separation line') # separation line

    plt.xlabel('t')
    plt.ylabel('sin(t) and cos(t)')
    plt.xlim(t[0], t[-1])
    plt.ylim(-1.2, 4)
    plt.legend(loc='upper right')
    plt.text(14, 2, "train", size = 15, alpha = 1.0)
    plt.text(20, 2, "test", size = 15, alpha = 1.0)

    plt.show()
