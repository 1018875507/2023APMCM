
#第一问的缺失值、异常值检测
setwd(dir = "E:\\数学建模\\异常值检测")
library(readxl)
library(writexl)
library(mice)
library(VIM)
library(gridExtra)


#数据预处理，缺失值、异常值
data1 <- read_excel("第一问数据统计2.xlsx")
colSums(is.na(data1)) 
#mice包中的md.pattern，形成缺失表
md.pattern(data1)

#par(mfrow = c(2, 2))
aggr(data1, prop = F, number = T)



#异常值检测
rm(list=ls())
dat1 <- read_excel("第一问数据统计2.xlsx")
op <- par(no.readonly=TRUE)
par(bty = "l")
boxplot(dat1$NEVS,NULL, names = c("NEVS","GDP"),col = "red",pch = 4,lwd = 1.5,at = c(1,2))
boxplot(dat1$NEVS,col = "blue",lwd = 1.5,notch = T,add = T,at = 2)
par(op)

boxplot(dat1$FAI,NULL, names = ("FAI"),col = "red",pch = 4,lwd = 1.5)
boxplot(dat1$NEVMS,col = "blue",lwd = 1.5,notch = T,add = T,at = 2)
par(op)  

boxplot(dat1$FAI,dat1$GDP,names = c("FAI","GDP"),col = colors()[10:11])
boxplot(dat1$NEVS,dat1$NEVMS,dat1$SNEVS,names = c("NEVS","NEVMS","SNEVS"),col = colors()[3:13])
boxplot(dat1$NEVSA,dat1$CPI,dat1$NCP,names = c("NEVSA","CPI","NCP"),col = colors()[15:25])


