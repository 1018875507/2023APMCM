function dxdt=differential(t,x)
dxdt=[x(1)*(1-x(1))*(4-0.1-4*x(2));x(2)*(1-x(2))*(-3+4*x(1))];
end %[x(1)*(1-x(1))*(A-0.5-A*Y));       x(2)*(1-x(2))*(-RT+A*X)]
                


clear 
%y-x
for i=0.1:0.4:0.9
    for j=0.1:0.4:0.9
        [T,Y]=ode45('differential',[0 20],[i j]);
        figure(1)
        grid on
        plot(T,Y(:,1),'r--','linewidth',1)
        hold on
        plot(T,Y(:,2),'b--','linewidth',1)
        hold on
        
    end
end
axis([0 20 -0.1 1.1]);
set(gca,'XTick',[0:2:20],'YTick',[-0.1:0.1:1.1])

