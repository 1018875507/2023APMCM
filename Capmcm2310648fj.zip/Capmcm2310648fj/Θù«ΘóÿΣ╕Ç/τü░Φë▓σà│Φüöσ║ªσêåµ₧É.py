clear;clc;
load X.mat; % Load the dataset named X.mat

% Get the number of rows and columns
r = size(X,1);
c = size(X,2);

% First, normalize the original index matrix
% Convert the second column from a middle-type to a max-type
middle = input("Please enter the optimal middle value: ");
M = max(abs(X(:,2)-middle));
for i=1:r
    X(i,2) = 1-abs(X(i,2)-middle)/M;
end

% Convert the third column from a min-type to a max-type
max_value = max(X(:,3)); 
X(:,3) = abs(X(:,3)-max_value);

% Convert the fourth column from a range-type to a max-type
a = input("Please enter the lower bound of the range: ");
b = input("Please enter the upper bound of the range: ");
M = max(a-min(X(:,4)),max(X(:,4))-b);
for i=1:r
    if (X(i,4) < a)
        X(i,4) = 1-(a-X(i,4))/M;
    elseif (X(i,4) <= b && X(i,4) >= a)
        X(i,4) = 1;
    else
        X(i,4) = 1-(X(i,4)-b)/M;
    end
end

disp("The matrix after normalization:");
disp(X);

% Preprocess the normalized matrix to eliminate the impact of dimensions
avg = repmat(mean(X),r,1);
new_X = X./avg;

% Extract the maximum value of each row from the preprocessed matrix to form the reference sequence (fictitious)
Y = max(new_X,[],2);

% Calculate the grey relational degree between each indicator and the reference sequence
% First, subtract the elements of the new_X matrix from the corresponding elements of the reference sequence and take the absolute value
Y2 = repmat(Y,1,c);
new_X = abs(new_X-Y2);
a = min(min(new_X)); % The minimum value in the entire matrix
b = max(max(new_X)); % The maximum value in the entire matrix
ro = 0.5;
new_X = (a+ro*b)./(new_X+ro*b);

disp("The grey relational degrees of each indicator to the reference sequence are:");
gamma = mean(new_X)
