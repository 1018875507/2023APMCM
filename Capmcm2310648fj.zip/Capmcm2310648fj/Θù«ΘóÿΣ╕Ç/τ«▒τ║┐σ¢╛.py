import matplotlib.pyplot as plt

# Create subplots with 1 row and 7 columns
fig, axes = plt.subplots(1, 7)

# Define color settings for the boxplot elements
color = dict(boxes='DarkGreen', whiskers='DarkOrange', medians='DarkBlue', caps='Red')
# 'boxes' represent the box body, 'whiskers' represent the whisker lines
# 'medians' represent the median value of the data, 'caps' represent the limits of the maximum and minimum values

# Plot a boxplot for the data (assuming 'data22' is your DataFrame containing the data)
data22.plot(kind='box', ax=axes, subplots=True, title='Interlayered - Box Plot', color=color, sym='r+', 
            figsize=(26, 24), fontsize=13)
# The 'sym' parameter specifies the marking style for outliers

# Setting the y-label for each subplot (it appears you may have mistakenly set the label for only one axis multiple times)
axes[0].set_ylabel('Label for Subplot 1')
axes[1].set_ylabel('Label for Subplot 2')
axes[2].set_ylabel('Label for Subplot 3')
axes[3].set_ylabel('Label for Subplot 4')
axes[4].set_ylabel('Label for Subplot 5')
axes[5].set_ylabel('Label for Subplot 6')
axes[6].set_ylabel('Label for Subplot 7')

# Adjust the spacing between the subplots
fig.subplots_adjust(wspace=2, hspace=2)

# Save the plotted figure as "p1.png"
fig.savefig("p1.png")
